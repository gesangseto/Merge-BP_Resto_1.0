Installation:

1. Download and install node-js => https://nodejs.org/dist/v14.17.3/node-v14.17.3-x64.msi
2. Open CMD and run command "npm install pm2 -g"

Running API using CMD with this command:

# npm install

# pm2 start server.js --name "APP-RESTO"

See Log using CMD with this command:

# pm2 logs
